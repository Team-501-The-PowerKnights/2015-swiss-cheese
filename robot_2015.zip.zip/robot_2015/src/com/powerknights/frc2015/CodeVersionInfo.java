
package com.powerknights.frc2015;


public class CodeVersionInfo
{

   public static final String version = "MM 5.000 20150528 204405";

}
